"""Exact, approved hidden-reference transitions; never public input overrides."""
import hashlib
import yaml

from benchmark.common.api import digest, identity, load, owned


def approved_dispositions(registry):
    result = {}
    for entry in registry.get('dispositions', []):
        if digest(owned(entry['path'])) != entry['sha256']:
            raise ValueError('Reference disposition evidence changed')
        record = load(owned(entry['path']))
        if (record.get('schema') != 'autodriver.reference-adoption/v1' or
                record.get('status') != 'adopted' or
                identity({k:v for k,v in record.items() if k != 'adoption_identity'}) != record.get('adoption_identity')):
            raise ValueError('Invalid reference disposition identity')
        approval = record['approval']
        if not approval.get('answer') or digest(owned(approval['review_path'])) != approval['review_sha256']:
            raise ValueError('Reference approval review changed')
        review = load(owned(approval['review_path']))
        if (review.get('review_identity') != approval['review_identity'] or
                identity({k:v for k,v in review.items() if k != 'review_identity'}) != approval['review_identity']):
            raise ValueError('Reference approval review identity mismatch')
        scopes = {s['task_id']: s for s in review['scope']}
        for scope in record['scope']:
            approved = scopes.get(scope['task_id'])
            if approved is None or any(scope.get(k) != v for k,v in approved.items()):
                raise ValueError('Reference disposition exceeds approved scope')
            for path, expected in ((scope['old_reference'], scope['old_reference_sha256']),
                                   (scope['proposed_new_reference'], scope['new_reference_sha256']),
                                   (scope['repair_patch'], scope['repair_patch_sha256']),
                                   (scope['evaluation_report'], scope['evaluation_report_sha256']),
                                   (scope['task_path'], scope['new_task_sha256'])):
                if digest(owned(path)) != expected:
                    raise ValueError('Approved reference material changed: ' + path)
            for state in ('old', 'new'):
                if hashlib.sha256(scope[state + '_task_text'].encode()).hexdigest() != scope[state + '_task_sha256']:
                    raise ValueError('Reference task snapshot mismatch')
            old = yaml.safe_load(scope['old_task_text'])
            new = yaml.safe_load(scope['new_task_text'])
            if old['task_id'] != scope['task_id'] or new['task_id'] != scope['task_id']:
                raise ValueError('Reference task identity mismatch')
            old['reference']['files'] = {
                name: scope['proposed_new_reference'] if path == scope['old_reference'] else path
                for name, path in old['reference']['files'].items()}
            if old != new or scope['old_task_sha256'] == scope['new_task_sha256']:
                raise ValueError('Reference disposition changes public task content')
            finding = scope['finding_id']
            if finding in result:
                raise ValueError('Duplicate reference disposition')
            result[finding] = {**scope, 'adoption_identity': record['adoption_identity'],
                               'disposition_path': entry['path'], 'disposition_sha256': entry['sha256']}
    return result


def reference_transition(task_id, task_path, old_hash, new_hash):
    from benchmark.common.reference_review import REGISTRY
    for scope in approved_dispositions(load(owned(REGISTRY))).values():
        if (scope['task_id'], scope['task_path'], scope['old_task_sha256'], scope['new_task_sha256']) == (
                task_id, task_path, old_hash, new_hash):
            return {k: scope[k] for k in ('adoption_identity', 'disposition_path', 'disposition_sha256',
                                         'old_task_sha256', 'new_task_sha256')}
    raise ValueError('Task/source/public target material changed without exact approved reference transition')
