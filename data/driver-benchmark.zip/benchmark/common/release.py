"""Release identity verification. Verification never invokes source compilation."""
from pathlib import Path
import os

from benchmark.common.api import ROOT, digest, identity, inventory, load, owned, save, resolve_task, task_paths
from benchmark.common.source.validate import verify_source
from benchmark.common.hardware.package import firmware_path


def owned_files():
    result = {}
    for dirname in ("benchmark", "method", "tests", "plot", "docs", "dependencies"):
        base = ROOT / dirname
        for path in base.rglob("*"):
            if path.is_relative_to(ROOT / "method/autoembed/knowledge"):
                # Runtime-generated, immutable knowledge has its own identity.
                # Every experiment binds a validated knowledge manifest.
                continue
            if "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            if path.is_symlink():
                raise ValueError("Owned source must not be a link: " + str(path))
            if path.is_file():
                result[path.relative_to(ROOT).as_posix()] = digest(path)
    for name in ("README.md", "AGENTS.md", "pyproject.toml"):
        result[name] = digest(ROOT / name)
    return result


def validation_identity(task):
    """Bind execution semantics, separately from the whole artifact identity.

    Offline installation and experiment scheduling are release-owned files but
    do not change a candidate's native build or independent behavior model.
    """
    files = task.files()
    for name in ("benchmark/common/api.py", "benchmark/common/execution.py",
                 "benchmark/common/submission.py", "benchmark/common/release.py",
                 "benchmark/common/source/configuration.py",
                 "tests/common/pipeline.py", "tests/common/sandbox.py"):
        files[name] = digest(owned(name))
    for base in (ROOT / "benchmark/common/target", ROOT / "benchmark/common/evaluation",
                 ROOT / "benchmark/common/applications", ROOT / "benchmark/common/hardware",
                 owned(task.spec["evaluation"]["suite"]).parent,
                 owned(task.spec["target"]["profile"]).parent):
        for path in base.rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                files[path.relative_to(ROOT).as_posix()] = digest(path)
    return identity(files)


def verify_release():
    manifest = load(ROOT / "manifest.json")
    if manifest.get("schema") != "autodriver.artifact/v1" or manifest.get("status") != "released":
        raise ValueError("No completed native artifact release is available")
    if manifest.get("release_identity") != identity({k: v for k, v in manifest.items() if k != "release_identity"}):
        raise ValueError("Frozen release manifest identity changed")
    if manifest["files"] != owned_files():
        raise ValueError("Frozen artifact materials changed")
    if "reference_review" in manifest:
        from benchmark.common.reference_review import verify_reference_reviews
        if verify_reference_reviews() != manifest["reference_review"]:
            raise ValueError("Frozen reference review changed")
    resources = load(ROOT / "third_party/sources.lock")
    actual = inventory(ROOT / "third_party", links=True)
    actual.pop("sources.lock", None)
    if resources["files"] != actual or manifest["resources_identity"] != identity(actual):
        raise ValueError("Frozen shared dependencies changed")
    if set(manifest["tasks"]) != set(task_paths()):
        raise ValueError("Task population changed")
    for name in task_paths():
        task = resolve_task(name)
        verify_source(task)
        if identity(task.files()) != manifest["tasks"][name]["task_identity"]:
            raise ValueError("Task identity changed: " + name)
    return {"schema": "autodriver.release-verification/v1", "status": "pass",
            "release_identity": manifest["release_identity"], "task_count": len(manifest["tasks"]),
            "source_compilations": 0}


def freeze(batch, acceptance):
    from benchmark.common.reference_review import verify_reference_reviews
    reference_review = verify_reference_reviews()
    tasks = {}
    if len(task_paths()) != 44:
        raise ValueError("The release requires exactly 44 tasks")
    for name in task_paths():
        task = resolve_task(name)
        source = verify_source(task)
        trial = ROOT / "result/reference" / batch / "trials" / name / "SD/0"
        report = load(trial / "evaluation/report.json")
        if report["status"] != "pass" or report.get("validation_identity") != validation_identity(task):
            raise ValueError("Current reference has not passed release gates: " + name)
        tasks[name] = {"task_identity": identity(task.files()), "source_receipt_identity": identity(source),
                       "reference_report": str((trial / "evaluation/report.json").relative_to(ROOT)),
                       "reference_report_sha256": digest(trial / "evaluation/report.json"),
                       "firmware_sha256": digest(firmware_path(trial, report))}
    evidence = load(owned(acceptance))
    if evidence["status"] != "pass" or evidence["input_count"] != 132:
        raise ValueError("Full acceptance has not passed")
    for gate in ("inputs", "controls", "boundaries", "relocation", "regression", "model_checks", "naming", "knowledge"):
        entry = evidence["gates"][gate]
        record = owned(entry["path"])
        if digest(record) != entry["sha256"] or load(record)["status"] != "pass":
            raise ValueError("Missing or changed acceptance gate: " + gate)
    resources = inventory(ROOT / "third_party", links=True)
    resources.pop("sources.lock", None)
    if load(ROOT / "third_party/sources.lock")["files"] != resources:
        raise ValueError("Shared dependencies changed; naming migration cannot refreeze them")
    method_states = {name: load(ROOT / "method" / name / "method.yaml")["live_execution"]
                     for name in ("autodriver", "codex_cli", "autoembed")}
    method_evidence = evidence.get("method_acceptance")
    if any(method_states[name] == "released" for name in ("codex_cli", "autoembed")):
        if not method_evidence:
            raise ValueError("Released live methods require method acceptance evidence")
        record = owned(method_evidence["path"])
        if digest(record) != method_evidence["sha256"] or load(record)["status"] != "pass":
            raise ValueError("Changed or failed method acceptance")
    manifest = {"schema": "autodriver.artifact/v1", "revision": 4, "status": "released",
                "files": owned_files(), "resources_identity": identity(resources), "tasks": tasks,
                "acceptance": acceptance, "acceptance_sha256": digest(owned(acceptance)),
                "hardware": "New firmware requires identity-bound observations; prior passes are not inherited",
                "methods": method_states, "method_acceptance": method_evidence,
                "reference_review": reference_review,
                "offline_acceptance_model_calls": 0, "hardware_operations": 0}
    manifest["release_identity"] = identity(manifest)
    save(ROOT / "manifest.json", manifest)
    return manifest
