"""Release must account for reviewed reference defects, including diagnostics.

The registry binds immutable audit records. A green core aggregate cannot
override an open finding; disposition requires an explicit approved new
review record and registry revision, not an in-place audit edit.
"""
from benchmark.common.api import digest, load, owned

REGISTRY = "benchmark/common/policies/reference-reviews.json"


def verify_reference_reviews():
    registry = load(owned(REGISTRY))
    if registry.get("schema") != "autodriver.reference-review-registry/v1":
        raise ValueError("Missing reference review registry")
    if not isinstance(registry.get("records"), list) or not registry["records"]:
        raise ValueError("Reference review registry has no audit evidence")
    unresolved = []
    from benchmark.common.reference_dispositions import approved_dispositions
    dispositions = approved_dispositions(registry)
    used = set()
    for entry in registry["records"]:
        path = owned(entry["path"])
        if digest(path) != entry["sha256"]:
            raise ValueError("Reference review evidence changed: " + entry["path"])
        record = load(path)
        if record.get("release_blocked") is not False:
            for finding in record.get("findings", []):
                disposition = dispositions.get(finding["id"])
                if disposition is None:
                    unresolved.append(finding["id"])
                elif (disposition["task_id"] != finding["task_id"] or
                      disposition["old_reference_sha256"] != finding["reference_sha256"]):
                    raise ValueError("Reference disposition does not bind original finding")
                else:
                    used.add(finding["id"])
            if not record.get("findings"):
                unresolved.append(entry["path"] + ": review is not complete")
        elif record.get("findings"):
            # Preserve the original blocked audit. Repairs are separate,
            # hash-bound dispositions, never a toggled audit boolean.
            raise ValueError("Reference findings require explicit disposition review: " + entry["path"])
    if unresolved:
        raise ValueError("Release blocked by reference findings: " + ", ".join(unresolved))
    if set(dispositions) != used:
        raise ValueError("Reference disposition has no matching original finding")
    return {"status": "pass", "registry_sha256": digest(owned(REGISTRY)),
            "records": registry["records"], "dispositions": registry.get("dispositions", [])}
